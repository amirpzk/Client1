package Client;

/**
 * Created by amirpez on 11/11/17.
 */
public interface ImpClient {

    void startClient();

    void sendToServer(String text);

    public void closeStreams();

}
