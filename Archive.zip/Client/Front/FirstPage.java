package Front;

import javax.swing.*;

/**
 * Created by MaXxxiiiiiiiiiiiaR on 11/23/2017.
 */
public class FirstPage {


    private JPanel panel1;
    private JTextField textField1;
    private JButton button1;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
