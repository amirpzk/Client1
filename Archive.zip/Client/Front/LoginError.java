package Front;

import javax.swing.*;

/**
 * Created by amirpez on 11/15/17.
 */
public class LoginError extends JDialog {
    private JPanel panel1;

    public LoginError() {
        this.setContentPane(panel1);
        this.setSize(100,100);
        this.setVisible(true);
    }
}
